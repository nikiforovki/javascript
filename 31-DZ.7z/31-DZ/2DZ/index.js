// let input1 = document.getElementById('inputDescription');
// let input2 = document.getElementById('inputAmount');
// let input3 = document.getElementById('inputDate');
// let button = document.querySelector('button');
// let container = document.getElementById('expenses');
//
// function loadExpensed() {
//     return JSON.parse(localStorage.getItem('expenses')) || [];
// }
//
// function saveExpenses(expenses) {
//     localStorage.setItem('expenses', JSON.stringify(expenses));
// }
//
// button.onclick = function(event) {
//     event.preventDefault();
//
//     let description = input1.value;
//     let amount = input2.value;
//     let date = input3.value;
//
// const userRecords = {
//     description: description,
//     amount: amount,
//     date: date
// }
//
// localStorage.setItem('userRecords', JSON.stringify(userRecords))
// console.log('Данные', userRecords);
//
// }
//
// const userRecords = JSON.parse(localStorage.getItem('userRecords'))
//
// console.log(userRecords.description);

document.addEventListener("DOMContentLoaded", () => {
    // Исправленные ID согласно HTML
    const descriptionInput = document.getElementById('inputDescription');
    const amountInput = document.getElementById('inputAmount');
    const dateInput = document.getElementById('inputDate');
    const addButton = document.getElementById('set-btn');
    const container = document.getElementById('expenses-container');

    // Загрузка расходов из LocalStorage
    function loadExpenses() {
        return JSON.parse(localStorage.getItem('expenses')) || [];
    }

    // Сохранение расходов в LocalStorage
    function saveExpenses(expenses) {
        localStorage.setItem('expenses', JSON.stringify(expenses));
    }

    // Отображение расходов
    function renderExpenses() {
        const expenses = loadExpenses();
        container.innerHTML = '';

        expenses.forEach((expense, index) => {
            const expenseElement = document.createElement('div');
            expenseElement.className = 'expense-item';
            expenseElement.innerHTML = `
        <p><strong>${expense.description}</strong></p>
        <p>Сумма: ${expense.amount} ₽</p>
        <p>Дата: ${expense.date}</p>
        <button class="delete-btn" data-id="${index}">Удалить</button>
      `;
            container.appendChild(expenseElement);
        });

        // Обработчики удаления
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = btn.getAttribute('data-id');
                deleteExpense(parseInt(id));
            });
        });
    }

    // Удаление расхода
    function deleteExpense(id) {
        let expenses = loadExpenses();
        expenses = expenses.filter((_, index) => index !== id);
        saveExpenses(expenses);
        renderExpenses();
    }

    // Добавление расхода (исправлено!)
    addButton.addEventListener('click', (e) => {
        e.preventDefault(); // Предотвращаем перезагрузку формы

        const description = descriptionInput.value.trim();
        const amount = parseFloat(amountInput.value);
        const date = dateInput.value;

        if (!description || isNaN(amount) || !date) {
            alert('Заполните все поля корректно!');
            return;
        }

        const newExpense = { description, amount, date };
        const expenses = [...loadExpenses(), newExpense];
        saveExpenses(expenses);
        renderExpenses();

        // Очистка формы
        descriptionInput.value = '';
        amountInput.value = '';
        dateInput.value = '';
    });

    // Инициализация при загрузке
    renderExpenses();
});